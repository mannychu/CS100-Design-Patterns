#ifndef LEGACY_H
#define LEGACY_H

#include <string>

class Legacy {
    
    public:
    
        virtual bool execute() = 0;
};

#endif