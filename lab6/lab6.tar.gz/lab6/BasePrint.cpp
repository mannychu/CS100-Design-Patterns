#include "BasePrint.h"

#include <iostream>

using namespace std;

	/* Constructors */
	BasePrint::BasePrint() {
		this->value = 0;
	};


	BasePrint(double value){
		this->value = value;
	}

