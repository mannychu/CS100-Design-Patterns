using namespace std;
#include "BasePrint.h"

BasePrint::BasePrint()
{
    return;
}

BasePrint::BasePrint(double value)
{
    this->value = value;
    
    return;
}