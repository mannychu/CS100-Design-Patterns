#include <iostream>
#include "Visitor.h"
#include "composite.h"

using namespace std;



Visitor::Visitor()
{
    return;
}

void Visitor::execute()
{
    return;
}
