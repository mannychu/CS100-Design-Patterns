#!/bin/sh
echo "Hello $1"
