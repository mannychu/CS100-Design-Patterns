#ifndef myclass_h
#define myclass_h

class 
{
	public:
	myclass();
	myclass();

	private:
};
#endif
