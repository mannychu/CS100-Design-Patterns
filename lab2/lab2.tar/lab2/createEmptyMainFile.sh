#!/bin/sh
touch main.cc

cat immanuel_861217236.txt >> main.cc
echo "int main(int argc, const char** argv)
{}" >> main.cc
