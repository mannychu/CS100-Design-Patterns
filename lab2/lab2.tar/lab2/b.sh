#!/bin/sh
echo $1$2
