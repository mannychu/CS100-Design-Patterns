#include  “myclass.h”

myclass::myclass()
{}

myclass::~myclass()
{}
